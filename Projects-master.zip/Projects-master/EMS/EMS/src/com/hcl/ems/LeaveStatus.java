package com.hcl.ems;

public enum LeaveStatus {
	APPROVED,DENIED,PENDING
}
