package com.hcl.ems;

public enum LeaveTypes {
	EL
}
